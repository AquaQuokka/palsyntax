from setuptools import find_packages, setup
setup(
    name='palsyntax',
    packages=find_packages(include=["palsyntax"]),
    version='1.7.3',
    description='Make Python syntax more friendly for those coming from other languages!',
    author='AquaQuokka',
    license='WTFPL',
    install_requires=[],
    setup_requires=['pytest-runner'],
    tests_require=['pytest'],
    test_suite='tests',
)
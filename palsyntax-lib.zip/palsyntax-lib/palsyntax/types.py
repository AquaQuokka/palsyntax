num = int
double = float
boolean = bool
lenient = len
string = str

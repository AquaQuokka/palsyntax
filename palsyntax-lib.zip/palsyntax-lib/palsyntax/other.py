minimum = min
maximum = max
none = None
true = True
false = False